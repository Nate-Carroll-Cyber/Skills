# Testing Suite

### Quantitative Tests for `typescript_security_audit_checklist` Skill

To validate the efficacy of this skill, execute the following tests against a vulnerable sandbox repository:

1.  **The DTO Bypass Test:**
    * **Input:** Provide a code snippet where an Express route casts `req.body` directly to an `AdminUser` interface without validation, then uses `req.body.isAdmin` in logic.
    * **Expected Output:** The agent must flag this as a critical vulnerability ("Interface / DTO False Trust" and "Auth Bypass"), explaining that interfaces vanish at runtime, and provide a Zod schema implementation to validate and sanitize the input.
2.  **The Prototype Pollution Test:**
    * **Input:** Provide a function that recursively merges `req.body` into a configuration object using `Object.assign` or a custom unhardened merge function.
    * **Expected Output:** The agent must identify the Prototype Pollution vulnerability and recommend rejecting `__proto__` and `constructor` keys or utilizing a hardened merge library.
3.  **The Type Escape Grep Test:**
    * **Input:** Provide a file containing multiple instances of `as any`, `as unknown as String`, and `@ts-ignore` used to bypass compiler errors during JSON deserialization.
    * **Expected Output:** The agent must catalogue all instances of dangerous type escapes, explicitly state that `JSON.parse` output must be validated before use, and provide a remediated code block parsing to `unknown` followed by schema validation.
