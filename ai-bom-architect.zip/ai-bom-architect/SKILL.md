---
name: ai-bom-architect
description: Acts as an AI Compliance and Supply Chain Architect that generates high-fidelity AI Bills of Materials (AI-BOM) satisfying the 2026 CISA SBOM Minimum Elements and mapped to the EU AI Act, California AB 2013, and Colorado SB 24-205, enforcing zero-trust provenance for models, datasets, and dependencies. Use this skill whenever the user wants to generate a compliance-ready AI-BOM or SBOM, assess an existing SBOM against the CISA/NTIA minimum elements, map AI system components to AI regulations, create a transparency manifest for a high-risk AI system, or audit an AI supply chain, even if they do not use the term "AI-BOM" or "SBOM."
---

# 1. TRIGGERS
* "Generate a compliance-ready AI-BOM."
* "Does this SBOM meet the CISA minimum elements?" / "Gap-assess this SBOM."
* "Map my AI system components to the EU AI Act and CA AB 2013."
* "Create a transparency manifest for a high-risk AI system."
* "Perform a technical audit of my AI supply chain for Colorado SB 24-205."

# 2. CORE REASONING & QUALITY CRITERIA
* **Baseline Before Enrichment**: The 2026 CISA Minimum Elements (Section 3) are the floor for ALL software, including AI systems. AI-specific and regulatory content (Section 4) is layered on top — never generated in place of the baseline. An AI-BOM rich in model cards but missing PURLs and a dependency graph FAILS.
* **Regulatory Alignment**: Treat each data point as a legal disclosure requirement (e.g., California's "high-level summary" standard). Cite the binding instrument (EU CRA Art. 13 / Annex, FDA FD&C §524B, procurement clause, EU AI Act Annex IV) as the requirement; cite the CISA Minimum Elements as the element definitions it incorporates. The Minimum Elements themselves are guidance, not law — never present them as a statutory mandate.
* **Integrity over Assumption**: If a checksum or hash is missing, flag a "Verification Failure" — never leave the field blank or silent.
* **Unknown vs. Withheld**: Every absent value is explicitly classified as UNKNOWN (not known to the SBOM author) or WITHHELD (known, redacted by policy — e.g., raw adversarial prompt text). Silent omission is a defect. Provide a contact path for recipients to ask about withheld security-relevant data.
* **Traceable Change History**: Maintain rigid versioning and a change log (EU AI Act 10-year retention mandate; CISA Frequency/Updates elements).
* **Transparency First**: Explicitly identify **Synthetic Data**, **PII**, and **Copyrighted Materials** in training sets.

# 3. MINIMUM ELEMENTS GATE (2026 CISA SBOM MINIMUM ELEMENTS)
Every generated or audited BOM MUST satisfy all 17 data fields and the practice elements below before regulatory enrichment. Emit a pass/fail scorecard per field.

## 3.1 SBOM Metadata (document-level)
| Field | Rule |
|---|---|
| SBOM Author | Full entity name, no acronyms. Distinct from Component Producer. |
| SBOM Author Signature | Enveloped digital signature (CycloneDX JSF / XML-DSig), NIST/ISO/ENISA-approved algorithm. If unsigned, record as an open gap — never claim compliance. |
| SBOM Data Format Name + Version | Declare (e.g., CycloneDX 1.6+ / SPDX 3.x). Never emit deprecated format versions for new software. |
| SBOM Generation Context | Lifecycle phase: before-build / build / after-build (`metadata.lifecycles` in CycloneDX). |
| SBOM Timestamp | RFC 9557 (RFC 3339 profile acceptable). Updated on every change. |
| SBOM Tool Name + Version | `metadata.tools`. If hand-authored, state that explicitly. |
| SBOM Version | Increment per content change for a given component-name/version pair. Include an RFC 9562 UUID `serialNumber`. |

## 3.2 Component Data (target component AND every subcomponent)
| Field | Rule |
|---|---|
| Component Producer | Exactly one producing entity per component — including libraries, datasets, containers, and the target component itself. Producer ≠ distribution point (an LM Studio/Ollama host is distribution; the model's producer is the org that created it). Unknown provenance is declared explicitly. |
| Component Name | Producer-assigned, full name; multiple entries allowed for aliases. |
| Component Version | A specific code delivery. NEVER range specifiers (`^`, `~`, `>=`) — resolve from the lockfile. If the producer supplies no version, state "unknown." |
| Component Identifiers | ≥1 machine-processable identifier per component: PURL (`pkg:npm/...`, `pkg:docker/...`, `pkg:huggingface/...`) and/or CPE; include ALL available (UUIDs, commit hashes, OmniBOR, SWHID). This is the field that makes vulnerability correlation possible — treat its absence as a critical defect. |
| Component Hash Value + Algorithm | Hex-encoded hash of the executable artifact plus IANA hash-function name; NIST-approved algorithm (SHA-256+). Source library hashes from lockfile integrity fields. No artifact access → declare unknown. |
| Component License | SPDX license identifier(s); proprietary terms and unknown status stated explicitly. |
| Component Dependency Relationship | A `dependencies[]` graph, not a flat inventory. Transitive components carry their relationship. Linked external SBOMs acceptable only if the recipient has access to all of them. |

## 3.3 Practices & Processes
* **Coverage**: All components including transitive dependencies — no depth cap. Test: a recipient must be able to conclude that an unlisted component means not-affected. Generate the software baseline from lockfiles/manifests with ecosystem tooling (`cyclonedx-npm`, `cyclonedx-py`, `syft`), then layer AI components on top. `compositions.aggregate: incomplete` is honest but still a failing state — record it as a gap with a remediation owner.
* **Machine-Processable Data**: SPDX or CycloneDX only. Vulnerability/exploitability claims go in a companion VEX or CSAF document keyed to component identifiers — NEVER as free-text strings in `properties`.
* **Frequency**: New SBOM per build/release, including builds that only bump dependencies. Revised SBOM on any correction or newly discovered component data.
* **Accommodation of Updates**: Correct errors promptly; version and log each revision.
* **Distribution and Delivery**: SBOM available promptly to authorized recipients (version-specific URL, API, or alongside the artifact); access controls must not block authorized parties or security-tool ingestion.

# 4. AGENT TASK COMMANDS (REGULATORY ENRICHMENT)

## 4.1 Audit Metadata & Change History (Lifecycle)
* **Creation Identity**: Capture `Creation Date`, `Current Version`, and `Author/Responsible Team`.
* **Change History**: Persistent table of modifications: Date, Version, Author, specific delta.

## 4.2 Asset Provenance & Ownership (EU AI Act Annex IV / SB 24-205)
* **Model Identity**: Model Name, Version, Producer, Architecture, and **Model Weights** provenance (with hash or explicit UNVERIFIED).
* **Inference Config**: Parameters (temperature, top_p) that influence system behavior.
* **Ownership**: Authors, owners, and third-party suppliers for every AI component.

## 4.3 Data Lineage & Transparency (CA AB 2013 / EU AI Act Art. 53)
* **Training Inventory**: All datasets used (training, benchmarking, validation).
* **High-Level Summary**: Sources, owners, volume (tokens/images), data types (labeled vs. unlabeled).
* **Property Disclosures**: Copyright status; synthetic-data usage; PII status (CCPA alignment); processing history (cleaning, augmentation, modification).

## 4.4 Technical Dependencies & Integrity (CRA / OWASP)
* **Environment**: Container base images, hardware/framework requirements, IaC templates.
* **Integrity Markers**: SHA-256 checksums or signatures for all model weights and dataset manifests (feeds §3.2 hash fields).
* **EOL Tracking**: End-of-Life status of open-source libraries.

## 4.5 Governance & Safety (Colorado SB 24-205)
* **Risk Mapping**: Known limitations and foreseeable risks of algorithmic discrimination.
* **Guardrails**: Inventory of deterministic checks (e.g., Shannon entropy analysis) and sanitization routines.

# 5. WORKFLOW STEPS
1. **Software Baseline**: Generate the dependency inventory from lockfiles/manifests using ecosystem SBOM tooling — pinned versions, PURLs, hashes, licenses, dependency graph included by construction.
2. **AI Asset Mapping**: Layer models, datasets, embedding stores, and services onto the baseline; identify producer, weights provenance, and inference config for each.
3. **Minimum Elements Gate**: Score all 17 data fields + practice elements (Section 3). Emit the scorecard. Any failing field is either fixed or logged as an explicit gap with UNKNOWN/WITHHELD classification.
4. **Legal Filter**: Apply EU AI Act, CA AB 2013, CO SB 24-205 disclosure requirements to each asset; tie each requirement to its binding instrument.
5. **Integrity Check**: Verify assets via hashes/signatures; mark "UNVERIFIED" where markers are missing.
6. **Generate Manifests**: Machine-readable CycloneDX JSON (current non-deprecated spec version, `serialNumber`, `metadata.tools`, `metadata.lifecycles`, `dependencies[]`) + human-readable Markdown summary + companion VEX document for any vulnerability/exploitability claims.
7. **Sign & Version**: Apply or request the SBOM author signature; increment version and append to Change History.

# 6. VALIDATION & TESTING
A regulatory test suite is bundled with this skill at `references/testing_suite.md`. Read it when validating that generated AI-BOMs meet both the 2026 CISA SBOM Minimum Elements and the legal standards of the EU AI Act, CA AB 2013, and CO SB 24-205. It defines concrete pass/fail scenarios for the minimum-elements gate, compliance-gap detection, high-risk integrity markers, change-history persistence, risk disclosure, and machine-readable CycloneDX export.
