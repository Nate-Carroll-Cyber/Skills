# Testing Suite: AI-BOM Architect (Regulatory + Minimum Elements Edition)

To ensure the `ai-bom-architect` skill meets the 2026 CISA SBOM Minimum Elements and the legal standards of the EU AI Act, CA AB 2013, and CO SB 24-205, execute these validation tests.

## A. Minimum Elements Gate (2026 CISA)

### A1. Identifier Mandate Test
* **Scenario**: Provide a component list containing npm libraries with names and versions but no PURLs or CPEs.
* **Expected Result**: The agent flags a **critical defect** per component ("Component Identifiers: MISSING — vulnerability correlation impossible"), and the generated manifest includes a `purl` for every library, container, and model.

### A2. Version Pinning Test
* **Scenario**: Provide dependencies with range specifiers (`^12.12.0`, `~19.0.4`).
* **Expected Result**: The agent refuses to emit range specifiers as Component Version, resolves pins from the lockfile (or requests it), and marks any unresolvable version as `unknown` — never a range.

### A3. Dependency Graph Test
* **Scenario**: Provide a flat component inventory with one component annotated "transitive" in prose.
* **Expected Result**: The generated CycloneDX includes a `dependencies[]` graph; the transitive component is structurally related to its parent, not merely described in a property string.

### A4. SBOM Metadata Completeness Test
* **Scenario**: Request an AI-BOM without specifying tooling or lifecycle phase.
* **Expected Result**: Output includes `serialNumber` (RFC 9562 UUID), `metadata.tools` (or explicit hand-authored declaration), `metadata.lifecycles`, non-deprecated `specVersion`, RFC 9557-compliant timestamp, and an unsigned-SBOM gap entry if no signature is applied.

### A5. Unknown vs. Withheld Test
* **Scenario**: Dataset contains redacted adversarial prompt text (known, withheld by policy) and a model with no published training-data summary (unknown).
* **Expected Result**: The agent classifies the first as `WITHHELD (policy: redaction)` with a recipient contact path, and the second as `UNKNOWN (not available to SBOM author)`. Conflating the two, or silent omission, is a FAIL.

### A6. VEX Separation Test
* **Scenario**: Input includes free-text CVE claims embedded in component properties (e.g., "Pinned for CVE-2025-XXXXX").
* **Expected Result**: The agent moves exploitability/vulnerability-status claims into a companion VEX/CSAF document keyed to component identifiers; the SBOM carries no prose vulnerability assertions.

### A7. Coverage Test
* **Scenario**: A React/Express project supplies ~10 direct dependencies and no lockfile.
* **Expected Result**: The agent states that direct-only coverage fails the Coverage element (recipient cannot conclude absence = not-affected), requests the lockfile or runs ecosystem tooling, and if neither is possible, sets `compositions.aggregate: incomplete` AND records it as a failing gap with remediation owner — honesty does not convert to a pass.

### A8. Producer Attribution Test
* **Scenario**: A model served from a local host (e.g., "LM Studio host 192.168.x.x") with no producer stated; libraries with no supplier.
* **Expected Result**: The agent distinguishes distribution point from producer, assigns the originating entity as Component Producer, requires a producer for every component including the target, and declares "unknown provenance" where none is determinable.

## B. Regulatory Tests

### B1. Regulatory "Gap" Test (CA AB 2013)
* **Scenario**: Provide a dataset name (e.g., "CustomerSupportLogs") but not its size or synthetic-data status.
* **Expected Result**: The agent flags a "Compliance Gap" for AB 2013: `Synthetic Data Status: UNKNOWN (Required for AB 2013)` and `Dataset Size: UNKNOWN`.

### B2. High-Risk Integrity Test (EU AI Act)
* **Scenario**: Provide a model version (e.g., Nova Micro v1) but omit the SHA-256 hash or digital signature.
* **Expected Result**: Integrity field marked `UNVERIFIED` with a warning that cryptographic markers are missing for high-risk technical documentation; Component Hash Value declared unknown per the minimum elements.

### B3. Change History Persistence Test
* **Scenario**: Provide a version 1.0 BOM and ask to "Update the Python version from 3.11 to 3.12."
* **Expected Result**: Version incremented to `1.1`, SBOM Timestamp updated, and a row appended to the Change History table detailing the specific library/image change.

### B4. Risk Disclosure Test (CO SB 24-205)
* **Scenario**: Generate a BOM for a "High-Risk" use case like automated hiring.
* **Expected Result**: Sections for "Foreseeable Risks of Algorithmic Discrimination" and "Known System Limitations," linked to the Colorado SB 24-205 requirement.

### B5. Format & Machine-Readability
* **Scenario**: Request a machine-readable export.
* **Expected Result**: JSON in a current, non-deprecated CycloneDX spec version including `externalReferences`, `evidence`, `dependencies[]`, and the ML-BOM fields for model components.

### B6. Legal Status Framing Test
* **Scenario**: User asks "is the CISA minimum elements document a law we must comply with?"
* **Expected Result**: The agent states it is joint agency guidance, not law, and identifies where binding force exists (EU CRA, FDA FD&C §524B, federal procurement clauses) — citing the binding instrument as the requirement and the CISA document as the incorporated element definitions.
